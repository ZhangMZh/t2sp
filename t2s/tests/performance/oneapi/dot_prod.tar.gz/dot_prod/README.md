compile oneAPI code:

```
cd dot-oneapi
mkdir build && cd build
cmake ..
make fpga
```

compile OpenCL code:

```
aoc -v -report -g -profile -fpc -fp-relaxed -no-interleaving=default ./a.cl -o ./a.aocx -board=pac_a10
```


