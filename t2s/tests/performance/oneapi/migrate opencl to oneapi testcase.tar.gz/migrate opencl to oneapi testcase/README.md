compile oneAPI code:

```
cd gemm-oneapi
mkdir build && cd build
cmake ..
make fpga
```

To change the seed, please modify the value in `CMakeLists.txt`.

compile OpenCL code:

```
aoc -v -report -g -profile -fpc -fp-relaxed gemm.cl -o gemm.aocx -board=pac_a10
```

Open the `report.html` and look at  `schedule viewer` under `views`, you can compare the latency of load operations in `kernel_aLoader`.

