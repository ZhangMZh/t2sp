#pragma once

#include <iostream>
#include <list>
#include <stdlib.h>
#include <vector>

#include <sycl/ext/intel/fpga_extensions.hpp>
#include <sycl/sycl.hpp>

#define I 128
#define J 128
#define K 256
#ifdef FPGA_EMULATOR
#define BATCH_SIZE 128
#else
#define BATCH_SIZE 16384
#endif

#define COLS_COMPONENT 128
#define FIXED_ITERATIONS 64

#define M_MINUS_COLS                                                           \
    (FIXED_ITERATIONS > COLS_COMPONENT ? FIXED_ITERATIONS - COLS_COMPONENT : 0)

#define ITERATIONS                                                             \
    (COLS_COMPONENT + M_MINUS_COLS +                                           \
     (COLS_COMPONENT + 1) * COLS_COMPONENT / 2 +                               \
     FIXED_ITERATIONS * (FIXED_ITERATIONS - 1) / 2 -                           \
     M_MINUS_COLS * (M_MINUS_COLS - 1) / 2)

constexpr size_t batch_size = BATCH_SIZE;
constexpr size_t num_elem_A = J * K * BATCH_SIZE;
constexpr size_t num_elem_Q = K * I * BATCH_SIZE;
constexpr size_t num_elem_R = J * (I + 1) * BATCH_SIZE / 2;

void qrd(float *A, float *Q, float *R, sycl::queue &q) {
    std::vector<sycl::event> oneapi_kernel_events;
    float *serialized_A = (float *)malloc(num_elem_A * sizeof(float));
    float *serialized_Q = (float *)malloc(num_elem_Q * sizeof(float));
    float *serialized_R = (float *)malloc(num_elem_R * sizeof(float));
    float *serialized_A_device = sycl::malloc_device<float>(num_elem_A, q);
    float *serialized_Q_device = sycl::malloc_device<float>(num_elem_Q, q);
    float *serialized_R_device = sycl::malloc_device<float>(num_elem_R, q);

    // kernel_A_serializer
    std::cout << "kernel_A_serializer" << std::endl;
    size_t addr = 0;
    for (size_t b = 0; b < BATCH_SIZE; b++) {
        for (size_t j = 0; j < J; j++) {
            for (size_t k = 0; k < K; k++) {
                serialized_A[addr++] = A[(j + k * J + b * J * K)];
            }
        }
    }

    std::cout << "memcpy matrix A host->device" << std::endl;
    q.memcpy(serialized_A_device, serialized_A, num_elem_A * sizeof(float))
        .wait();

    // kernel_QR
    std::cout << "kernel_QR" << std::endl;
    oneapi_kernel_events.push_back(q.submit([&](sycl::handler &h) {
        h.single_task<class kernel_QR>([=]() {
            for (int _QR_s0_batch = 0; _QR_s0_batch < batch_size;
                 _QR_s0_batch++) {
                [[intel::fpga_memory(), intel::numbanks(32),
                  intel::bankwidth(32)]] float _temp_A[128][256];
                [[intel::fpga_memory(), intel::numbanks(32),
                  intel::bankwidth(32)]] float _temp_Q[128][256];
                // load matrix A
                int _addr_load_A = _QR_s0_batch * 32768;
                for (int _ALoader_s0_j = 0; _ALoader_s0_j < 128;
                     _ALoader_s0_j++) {
                    for (int _ALoader_s0_k_load = 0; _ALoader_s0_k_load < 32;
                         _ALoader_s0_k_load++) {
                        bool get[32];
#pragma unroll
                        for (int k = 0; k < 32; k++) {
                            get[k] = _ALoader_s0_k_load == k;
                        }
                        float tmp[8];
#pragma unroll
                        for (int k = 0; k < 8; k++) {
                            tmp[k] = serialized_A_device[_addr_load_A + k];
                        }
#pragma unroll
                        for (int k = 0; k < 32; k++) {
#pragma unroll
                            for (int t = 0; t < 8; t++) {
                                if (get[k]) {
                                    _temp_A[_ALoader_s0_j][k * 8 + t] = tmp[t];
                                }
                                tmp[t] = sycl::ext::intel::fpga_reg(tmp[t]);
                            }
                        }
                        int _0 = _addr_load_A;
                        int _2 = _0 + 8;
                        _addr_load_A = _2;
                    } // for _ALoader_s0_k_load
                }     // for _ALoader_s0_j

                int _QR_s0_i = -1;
                int _QR_s0_j = 0;
                int _addr_store_R = _QR_s0_batch * 8256;
                float _Xii, _i_r_Xii;
                float _s_or_i_shreg[128];
                float _Ai_shreg[256];
                float _vec_ti[256];
                [[intel::fpga_memory(), intel::numbanks(32),
                  intel::bankwidth(32)]] float _A_shreg[128][256];
                [[intel::initiation_interval(1)]]  // NO-FORMAT: Attribute
                [[intel::ivdep(FIXED_ITERATIONS)]] // NO-FORMAT: Attribute
                for (int _QR_s0_i_j = 0; _QR_s0_i_j < ITERATIONS;
                     _QR_s0_i_j++) {
                    float _vec_t[256];
                    float _sori_shreg[32];
                    bool i_ge_0[32], i_lt_0[32], j_ge_i[32], j_eq_i_plus_1[32],
                        j_eq_i[32];
#pragma unroll
                    for (int _QR_s0_k = 0; _QR_s0_k < 32; _QR_s0_k++) {
                        i_ge_0[_QR_s0_k] =
                            sycl::ext::intel::fpga_reg(_QR_s0_i >= 0);
                        i_lt_0[_QR_s0_k] =
                            sycl::ext::intel::fpga_reg(_QR_s0_i < 0);
                        j_ge_i[_QR_s0_k] =
                            sycl::ext::intel::fpga_reg(_QR_s0_j >= _QR_s0_i);
                        j_eq_i[_QR_s0_k] =
                            sycl::ext::intel::fpga_reg(_QR_s0_j == _QR_s0_i);
                        j_eq_i_plus_1[_QR_s0_k] = sycl::ext::intel::fpga_reg(
                            _QR_s0_j == _QR_s0_i + 1);
                        _sori_shreg[_QR_s0_k] =
                            sycl::ext::intel::fpga_reg(_s_or_i_shreg[_QR_s0_j]);
                    }

#pragma unroll
                    for (int _QR_s0_k = 0; _QR_s0_k < 256; _QR_s0_k++) {
                        _vec_t[_QR_s0_k] = _temp_A[_QR_s0_j][_QR_s0_k];
                        if (i_ge_0[_QR_s0_k / 8]) {
                            _vec_t[_QR_s0_k] = _A_shreg[_QR_s0_j][_QR_s0_k];
                        }
                        if (j_eq_i[_QR_s0_k / 8]) {
                            _Ai_shreg[_QR_s0_k] = _vec_t[_QR_s0_k];
                        }
                    }
#pragma unroll
                    for (int _QR_s0_k = 0; _QR_s0_k < 256; _QR_s0_k++) {
                        float _78, _79, _80;
                        if (j_eq_i[_QR_s0_k / 8]) {
                            _78 = 0.0f;
                        } else {
                            _78 = _vec_t[_QR_s0_k];
                        }
                        _79 = _Ai_shreg[_QR_s0_k];
                        if (i_lt_0[_QR_s0_k / 8]) {
                            _80 = 0.0f;
                        } else {
                            _80 = _sori_shreg[_QR_s0_k / 8];
                        }
                        float _81 = _79 * _80;
                        float _87 = _78 + _81;
                        _vec_t[_QR_s0_k] = _87;
                        if (j_ge_i[_QR_s0_k / 8]) {
                            _A_shreg[_QR_s0_j][_QR_s0_k] = _vec_t[_QR_s0_k];
                            // Output Q
                            _temp_Q[_QR_s0_j][_QR_s0_k] =
                                _A_shreg[_QR_s0_j][_QR_s0_k];
                        }
                        if (j_eq_i_plus_1[_QR_s0_k / 8]) {
                            _vec_ti[_QR_s0_k] = _vec_t[_QR_s0_k];
                        }
                    } // for _QR_s0_k

                    // inner product
                    float _Xij = 0.0f;
#pragma unroll
                    for (int _QR_s0_k = 0; _QR_s0_k < 256; _QR_s0_k++) {
                        float _113 = _vec_ti[_QR_s0_k];
                        float _114 = _vec_t[_QR_s0_k];
                        _Xij += _113 * _114;
                        //  if ((_QR_s0_k % 4) == 3)
                        //    _Xij = sycl::ext::intel::fpga_reg(_Xij);
                    } // for _QR_s0_k
                    if (_QR_s0_j == _QR_s0_i + 1) {
                        _Xii = _Xij;
                        _i_r_Xii = sycl::rsqrt(_Xij);
                    }
                    float _Sij = 0.0f - _Xij / _Xii;
                    if (_QR_s0_j == _QR_s0_i + 1) {
                        _s_or_i_shreg[_QR_s0_j] = _i_r_Xii;
                    } else {
                        _s_or_i_shreg[_QR_s0_j] = _Sij;
                    }

                    // Output R
                    bool _120 = 127 > _QR_s0_i;
                    bool _121 = _QR_s0_i < _QR_s0_j;
                    bool _122 = _120 && _121;
                    if (_122) {
                        float _126 = _Xij;
                        float _127;
                        bool _128 = _QR_s0_j == _QR_s0_i + 1;
                        if (_128) {
                            float _129 = sycl::sqrt(_126);
                            _127 = _129;
                        } // if _128
                        else {
                            float _134 = _i_r_Xii;
                            float _135 = _126 * _134;
                            _127 = _135;
                        } // if _128 else
                        float _138 = _127;
                        serialized_R_device[_addr_store_R] = _138;
                        int _155 = _addr_store_R;
                        int _156 = _155 + 1;
                        _addr_store_R = _156;
                        (void)_138;
                    } // if _124

                    _QR_s0_j++;
                    if (_QR_s0_j == COLS_COMPONENT) {
                        _QR_s0_i++;
                        _QR_s0_j =
                            _QR_s0_i < (COLS_COMPONENT - FIXED_ITERATIONS)
                                ? _QR_s0_i
                                : (COLS_COMPONENT - FIXED_ITERATIONS);
                    }
                }

                int _addr_store_Q = _QR_s0_batch * 32768;
                for (int _QUnloader_s0_i = 0; _QUnloader_s0_i < 128;
                     _QUnloader_s0_i++) {
                    for (int _QUnloader_s0_k_sotre = 0;
                         _QUnloader_s0_k_sotre < 32; _QUnloader_s0_k_sotre++) {
                        bool get[32];
#pragma unroll
                        for (int k = 0; k < 32; k++) {
                            get[k] = _QUnloader_s0_k_sotre == k;
                        }
                        float tmp[8];
#pragma unroll
                        for (int t = 0; t < 32; t++) {
#pragma unroll
                            for (int k = 0; k < 8; k++) {
                                if (get[t]) {
                                    tmp[k] =
                                        _temp_Q[_QUnloader_s0_i][t * 8 + k];
                                } else {
                                    tmp[k] = sycl::ext::intel::fpga_reg(tmp[k]);
                                }
                            }
                        }
#pragma unroll
                        for (int k = 0; k < 8; k++) {
                            serialized_Q_device[_addr_store_Q + k] = tmp[k];
                        }
                        int _169 = _addr_store_Q;
                        int _170 = _169 + 8;
                        _addr_store_Q = _170;
                    } // for _QUnloader_s0_k_sotre
                }     // for _QUnloader_s0_i
            }         // for _QR_s0_batch
        });
    }));

    for (unsigned int i = 0; i < oneapi_kernel_events.size(); i++) {
        oneapi_kernel_events.at(i).wait();
    };

    if (oneapi_kernel_events.size() > 0) {
        double k_earliest_start_time =
            oneapi_kernel_events.at(0)
                .get_profiling_info<
                    sycl::info::event_profiling::command_start>();
        double k_latest_end_time =
            oneapi_kernel_events.at(0)
                .get_profiling_info<sycl::info::event_profiling::command_end>();
        for (unsigned i = 1; i < oneapi_kernel_events.size(); i++) {
            double tmp_start =
                oneapi_kernel_events.at(i)
                    .get_profiling_info<
                        sycl::info::event_profiling::command_start>();
            double tmp_end =
                oneapi_kernel_events.at(i)
                    .get_profiling_info<
                        sycl::info::event_profiling::command_end>();
            if (tmp_start < k_earliest_start_time) {
                k_earliest_start_time = tmp_start;
            }
            if (tmp_end > k_latest_end_time) {
                k_latest_end_time = tmp_end;
            }
        }
        // Get time in ns
        double events_time = (k_latest_end_time - k_earliest_start_time);
        printf("  Time: %.5f ns\n", events_time);
        printf("  Throughput: %.5f matrices/s for matrices of size %d*%d\n",
               (double)batch_size * 1e9 / events_time, K, J);
    }

    std::cout << "memcpy matrix Q device->host" << std::endl;
    q.memcpy(serialized_Q, serialized_Q_device, num_elem_Q * sizeof(float))
        .wait();
    std::cout << "memcpy matrix R device->host" << std::endl;
    q.memcpy(serialized_R, serialized_R_device, num_elem_R * sizeof(float))
        .wait();

    // kernel_Q_deserializer
    std::cout << "kernel_Q_deserializer" << std::endl;
    addr = 0;
    for (size_t b = 0; b < BATCH_SIZE; b++) {
        for (size_t i = 0; i < I; i++) {
            for (size_t k = 0; k < K; k++) {
                Q[(k + i * K + b * I * K)] = serialized_Q[addr++];
            }
        }
    }

    // kernel_R_deserializer
    std::cout << "kernel_R_deserializer" << std::endl;
    addr = 0;
    for (size_t b = 0; b < BATCH_SIZE; b++) {
        for (size_t i = 0; i < I; i++) {
            for (size_t j = 0; j < J; j++) {
                if (j >= i) {
                    R[(j + i * J + b * I * J)] = serialized_R[addr++];
                } else {
                    R[(j + i * J + b * I * J)] = 0.0f;
                }
            }
        }
    }
    free(serialized_A);
    free(serialized_Q);
    free(serialized_R);
    sycl::free(serialized_A_device, q);
    sycl::free(serialized_Q_device, q);
    sycl::free(serialized_R_device, q);
}
