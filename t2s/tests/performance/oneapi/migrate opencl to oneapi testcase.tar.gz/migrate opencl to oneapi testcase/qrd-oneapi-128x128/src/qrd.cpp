#include <sycl/ext/intel/fpga_extensions.hpp>
#include <sycl/sycl.hpp>

#include "exception_handler.hpp"
#include "qrd.h"

int main(int argc, char *argv[]) {
#if defined(FPGA_EMULATOR)
    std::cout << "USING FPGA EMULATOR" << std::endl;
    sycl::ext::intel::fpga_emulator_selector device_selector;
#else
    std::cout << "USING FPGA HARDWARE" << std::endl;
    sycl::ext::intel::fpga_selector device_selector;
#endif
    sycl::queue q(device_selector, fpga_tools::exception_handler,
                  sycl::property::queue::enable_profiling());
    std::cout << "Device name: "
              << q.get_device().get_info<sycl::info::device::name>().c_str()
              << std::endl;

    float *A = (float *)malloc(num_elem_A * sizeof(float));
    float *Q = (float *)malloc(num_elem_Q * sizeof(float));
    float *R = (float *)malloc(J * I * BATCH_SIZE * sizeof(float));

    // Generate the random input matrices
    constexpr size_t kRandomSeed = 1138;
    constexpr size_t kRandomMin = 1;
    constexpr size_t kRandomMax = 10;
    srand(kRandomSeed);
    for (size_t b = 0; b < batch_size; b++) {
        for (size_t k = 0; k < K; k++) {
            for (size_t j = 0; j < J; j++) {
                int random_val = rand();
                float random_float =
                    random_val % (kRandomMax - kRandomMin) + kRandomMin;
                A[(j + k * J + b * J * K)] = random_float;
            }
        }
    }

    qrd(A, Q, R, q);

    bool passed = true;
    std::list<size_t> to_check;
    // Check at least matrix 0
    to_check.push_back(0);
    // Spot check the last and the middle one
    if (BATCH_SIZE > 2)
        to_check.push_back(BATCH_SIZE / 2);
    if (BATCH_SIZE > 1)
        to_check.push_back(BATCH_SIZE - 1);

    for (size_t b : to_check) {
        printf("\n*** Verifying results on input matrix %ld\n", b);
        // printf("*** Matrix Q: \n");
        // for (int k = 0; k < K; k++) {
        //     for (int i = 0; i < I; i++) {
        //         printf("%5.2f ", Q[(k + i * K + b * K * I)]);
        //     }
        //     printf("\n");
        // }

        // printf("*** Matrix R: \n");
        // for (int i = 0; i < I; i++) {
        //     for (int j = 0; j < J; j++) {
        //         printf("%5.2f ", R[(j + i * J + b * I * J)]);
        //     }
        //     printf("\n");
        // }

        // check if Q * R can reproduce the inputs
        // printf("*** Q * R [Input]\n");
        for (int k = 0; k < K; k++) {
            for (int j = 0; j < J; j++) {
                float golden = 0.0f;
                for (int i = 0; i < I; i++) {
                    golden +=
                        Q[(k + i * K + b * K * I)] * R[(j + i * J + b * I * J)];
                }
                bool correct = fabs(A[(j + k * J + b * J * K)] - golden) < 0.01;
                passed = passed && correct;
                // printf("%5.2f [%5.2f%s] ", golden, A[(j + k * J + b * J *
                // K)],
                //        correct ? "" : " !!");
            }
            // printf("\n");
        }
    }

    if (passed) {
        printf("[PASSED]\n");
    } else {
        printf("[FAILED]\n");
    }
    free(A);
    free(Q);
    free(R);
}
